# Pokémon: Shadow Eclipse

## 실행 방법

```bash
npm install
npm run dev
```

[http://localhost:3000](http://localhost:3000) 에서 플레이하세요.